<div class="header">
    <a href="index.php">Главная</a>
    <a href="puzzle.php">Загадки</a>
    <a href="guess.php">Угадайка</a>
    <a href="guess2.php">Угадайка для двух игроков</a>
    <a href="genpas.php">Генератор паролей</a>
</div>
